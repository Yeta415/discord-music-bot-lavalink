const { ActionRowBuilder, ButtonBuilder, ButtonStyle, EmbedBuilder } = require('discord.js');

module.exports = {
  createMusicEmbed(track, requester) {
    const embed = new EmbedBuilder()
      .setColor(0x1DB954)
      .setTitle(track.title)
      .setURL(track.uri)
      .setDescription(`🎶 **Lagu sedang diputar**`)
      .addFields(
        { name: '⏱ Durasi', value: track.duration ? `${Math.floor(track.duration / 60000)}:${('0' + Math.floor(track.duration % 60000 / 1000)).slice(-2)}` : 'Live', inline: true },
        { name: '👤 Diminta oleh', value: `<@${requester.id}>`, inline: true }
      )
      .setThumbnail(track.thumbnail || 'https://i.imgur.com/0k47lTn.png')
      .setTimestamp();

    const row = new ActionRowBuilder().addComponents(
      new ButtonBuilder().setCustomId('pause').setLabel('⏸️ Pause').setStyle(ButtonStyle.Secondary),
      new ButtonBuilder().setCustomId('resume').setLabel('▶️ Resume').setStyle(ButtonStyle.Secondary),
      new ButtonBuilder().setCustomId('skip').setLabel('⏭️ Skip').setStyle(ButtonStyle.Secondary),
      new ButtonBuilder().setCustomId('stop').setLabel('⏹️ Stop').setStyle(ButtonStyle.Danger)
    );

    return { embed, row };
  }
};
