module.exports = {
  name: "skip",
  async execute(message, args, client) {
    const player = client.manager.players.get(message.guild.id);
    if (!player) return message.reply("❌ Tidak ada lagu yang sedang diputar.");

    player.stop();
    message.channel.send("⏭️ Lagu dilewati.");
  }
};
