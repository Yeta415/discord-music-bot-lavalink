module.exports = {
  name: "play",
  async execute(message, args, client) {
    const query = args.join(" ");
    if (!query) return message.reply("🔍 Masukkan nama lagu atau link");

    const { channel } = message.member.voice;
    if (!channel) return message.reply("🔊 Gabung ke voice channel dulu!");

    const player = client.manager.create({
      guild: message.guild.id,
      voiceChannel: channel.id,
      textChannel: message.channel.id,
      selfDeafen: true,
    });

    if (!player.connected) player.connect();

    const res = await player.search(query, message.author);

    if (res.loadType === "NO_MATCHES") return message.reply("❌ Tidak ada lagu ditemukan!");
    player.queue.add(res.tracks[0]);

    message.channel.send(`▶️ Menambahkan: **${res.tracks[0].title}**`);
    if (!player.playing && !player.paused && !player.queue.size) player.play();
  }
};
