module.exports = {
  name: "lofi",
  async execute(message, args, client) {
    const { channel } = message.member.voice;
    if (!channel) return message.reply("Gabung voice channel dulu!");

    const player = client.manager.create({
      guild: message.guild.id,
      voiceChannel: channel.id,
      textChannel: message.channel.id,
      selfDeafen: true,
    });

    if (!player.connected) player.connect();

    player.queue.add({
      title: "Lofi Chill",
      uri: "https://www.youtube.com/watch?v=jfKfPfyJRdk",
    });

    message.channel.send("📻 Memutar Lofi Girl 24/7");
    player.play();
  }
};
