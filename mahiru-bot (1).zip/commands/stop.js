module.exports = {
  name: "stop",
  async execute(message, args, client) {
    const player = client.manager.players.get(message.guild.id);
    if (!player) return message.reply("❌ Tidak ada lagu yang sedang diputar.");

    player.destroy();
    message.channel.send("⏹️ Musik dihentikan.");
  }
};
